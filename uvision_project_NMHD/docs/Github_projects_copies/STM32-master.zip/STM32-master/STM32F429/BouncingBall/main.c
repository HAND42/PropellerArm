/**
  ******************************************************************************
  * @file    STemWin/STemWin_HelloWorld/Src/main.c
  * @author  MCD Application Team
  * @brief   This file provides main program functions
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright � 2017 STMicroelectronics International N.V. 
  * All rights reserved.</center></h2>
  *
  * Redistribution and use in source and binary forms, with or without 
  * modification, are permitted, provided that the following conditions are met:
  *
  * 1. Redistribution of source code must retain the above copyright notice, 
  *    this list of conditions and the following disclaimer.
  * 2. Redistributions in binary form must reproduce the above copyright notice,
  *    this list of conditions and the following disclaimer in the documentation
  *    and/or other materials provided with the distribution.
  * 3. Neither the name of STMicroelectronics nor the names of other 
  *    contributors to this software may be used to endorse or promote products 
  *    derived from this software without specific written permission.
  * 4. This software, including modifications and/or derivative works of this 
  *    software, must execute solely and exclusively on microcontroller or
  *    microprocessor devices manufactured by or for STMicroelectronics.
  * 5. Redistribution and use of this software other than as permitted under 
  *    this license is void and will automatically terminate your rights under 
  *    this license. 
  *
  * THIS SOFTWARE IS PROVIDED BY STMICROELECTRONICS AND CONTRIBUTORS "AS IS" 
  * AND ANY EXPRESS, IMPLIED OR STATUTORY WARRANTIES, INCLUDING, BUT NOT 
  * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
  * PARTICULAR PURPOSE AND NON-INFRINGEMENT OF THIRD PARTY INTELLECTUAL PROPERTY
  * RIGHTS ARE DISCLAIMED TO THE FULLEST EXTENT PERMITTED BY LAW. IN NO EVENT 
  * SHALL STMICROELECTRONICS OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
  * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
  * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, 
  * OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF 
  * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING 
  * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
  * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
  *
  ******************************************************************************
  */
/* Includes ------------------------------------------------------------------*/
#include "GUI.h"
#include "stm32f4xx_hal.h"
#include "stm32f4xx_hal_rng.h"
#include "stm32f4xx_hal.h"
#include "stm32f429i_discovery.h"
#include "stm32f429i_discovery_ts.h"
#include "stm32f429i_discovery_sdram.h"
#include "ili9341/ili9341.h" 

/* Private typedef -----------------------------------------------------------*/
typedef struct
{
	float x_;
	float y_;
} Point;

typedef struct
{
	float x_;
	float y_;
} Velocity;

typedef struct
{
  Point circleCenter;
  int circleRadius;
  Point upperLeft;
  Point lowerRight;
  Velocity velocity;
} CircleValues;

/* Private define ------------------------------------------------------------*/
#define XSIZE_PHYS 240
#define YSIZE_PHYS 320

/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
TIM_HandleTypeDef TimHandle;
uint32_t uwPrescalerValue = 0;

/* Private function prototypes -----------------------------------------------*/
static void BSP_Config(void);
static void SystemClock_Config(void);
void InitRandomNumberGenerator(RNG_HandleTypeDef* rngHandle);
uint32_t GenerateRandomNumber(RNG_HandleTypeDef* rngHandle);
Velocity GenerateRandomVelocity();
void InitCircle(CircleValues* circleValues);
void MoveCircle(CircleValues* circleValues);

/**
  * @brief  Main program
  * @param  None
  * @retval None
  */ 
int main(void)
{  
  /* STM32F4xx HAL library initialization:
       - Configure the Flash prefetch, instruction and Data caches
       - Configure the Systick to generate an interrupt each 1 msec
       - Set NVIC Group Priority to 4
       - Global MSP (MCU Support Package) initialization
     */
  HAL_Init();
  
  /* Initialize LCD and LEDs */
  BSP_Config();
  
  /* Configure the system clock to 180 MHz */
  SystemClock_Config();
  
  /* Init the STemWin GUI Library */
  GUI_Init();
  
  CircleValues circleValues;
  InitCircle(&circleValues);

  while(1) 
  {
    MoveCircle(&circleValues);
  }
}

/**
  * @brief  Initializes the STM32F429I-DISCO's LCD and LEDs resources.
  * @param  None
  * @retval None
  */
static void BSP_Config(void)
{
  /* Initializes the SDRAM device */
  BSP_SDRAM_Init();
  
  /* Initialize the Touch screen */
  BSP_TS_Init(240, 320);
  
  /* Enable the CRC Module */
  __HAL_RCC_CRC_CLK_ENABLE();
}


/**
  * @brief  System Clock Configuration
  *         The system Clock is configured as follow : 
  *            System Clock source            = PLL (HSE)
  *            SYSCLK(Hz)                     = 180000000
  *            HCLK(Hz)                       = 180000000
  *            AHB Prescaler                  = 1
  *            APB1 Prescaler                 = 4
  *            APB2 Prescaler                 = 2
  *            HSE Frequency(Hz)              = 8000000
  *            PLL_M                          = 8
  *            PLL_N                          = 360
  *            PLL_P                          = 2
  *            PLL_Q                          = 7
  *            VDD(V)                         = 3.3
  *            Main regulator output voltage  = Scale1 mode
  *            Flash Latency(WS)              = 5
  * @param  None
  * @retval None
  */
static void SystemClock_Config(void)
{
  RCC_ClkInitTypeDef RCC_ClkInitStruct;
  RCC_OscInitTypeDef RCC_OscInitStruct;
  
  /* Enable Power Control clock */
  __HAL_RCC_PWR_CLK_ENABLE();
  
  /* The voltage scaling allows optimizing the power consumption when the device is 
     clocked below the maximum system frequency, to update the voltage scaling value 
     regarding system frequency refer to product datasheet.  */
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);
  
  /* Enable HSE Oscillator and activate PLL with HSE as source */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLM = 8;
  RCC_OscInitStruct.PLL.PLLN = 360;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 7;
  HAL_RCC_OscConfig(&RCC_OscInitStruct);
  
  /* Activate the Over-Drive mode */
  HAL_PWREx_EnableOverDrive();
  
  /* Select PLL as system clock source and configure the HCLK, PCLK1 and PCLK2 
  clocks dividers */
  RCC_ClkInitStruct.ClockType = (RCC_CLOCKTYPE_SYSCLK | RCC_CLOCKTYPE_HCLK | RCC_CLOCKTYPE_PCLK1 | RCC_CLOCKTYPE_PCLK2);
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV4;  
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV2;  
  HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_5);
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *   where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t* file, uint32_t line)
{
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */

  /* Infinite loop */
  while (1)
  {
  }
}
#endif

void InitRandomNumberGenerator(RNG_HandleTypeDef* rngHandle)
{
  rngHandle->Instance = RNG;

  __HAL_RCC_RNG_CLK_ENABLE();

  HAL_RNG_MspInit(rngHandle);

  if(HAL_RNG_Init(rngHandle) != HAL_OK)
  {
	  while(1) { }
  }
}

uint32_t GenerateRandomNumber(RNG_HandleTypeDef* rngHandle)
{
  uint32_t randomNumber = 0;
  if(HAL_RNG_GenerateRandomNumber(rngHandle, &randomNumber) != HAL_OK)
  {
	  while(1) { }
  }

  return randomNumber;
}

Velocity GenerateRandomVelocity()
{
  RNG_HandleTypeDef rngHandle;
  InitRandomNumberGenerator(&rngHandle);

  const float accelerator = 2.0;
  const uint32_t maxUnsigned32 = 0xFFFFFFFF;

  Velocity velocity;
  velocity.x_ = (float)GenerateRandomNumber(&rngHandle) / (float)maxUnsigned32 * accelerator;
  velocity.y_ = (float)GenerateRandomNumber(&rngHandle) / (float)maxUnsigned32 * accelerator;

  return velocity;
}

void InitCircle(CircleValues* circleValues)
{
  circleValues->circleRadius = 10;
  circleValues->circleCenter.x_ = circleValues->circleRadius;
  circleValues->circleCenter.y_ = circleValues->circleRadius;
  circleValues->upperLeft.x_ = circleValues->upperLeft.y_ = circleValues->lowerRight.x_ = circleValues->lowerRight.y_ = 0;
  circleValues->velocity = GenerateRandomVelocity();

  GUI_SetBkColor(GUI_WHITE);
  GUI_Clear();
  GUI_SetColor(GUI_BLUE);
}

void MoveCircle(CircleValues* circleValues)
{
	GUI_ClearRect(circleValues->upperLeft.x_, circleValues->upperLeft.y_, circleValues->lowerRight.x_, circleValues->lowerRight.y_);
    GUI_FillCircle(circleValues->circleCenter.x_, circleValues->circleCenter.y_, circleValues->circleRadius);
    GUI_Delay(10);

    circleValues->upperLeft.x_ = circleValues->circleCenter.x_ - circleValues->circleRadius;
    circleValues->upperLeft.y_ = circleValues->circleCenter.y_ - circleValues->circleRadius;
    circleValues->lowerRight.x_ = circleValues->circleCenter.x_ + circleValues->circleRadius;
    circleValues->lowerRight.y_ = circleValues->circleCenter.y_ + circleValues->circleRadius;

    if(circleValues->upperLeft.x_ < 0 || circleValues->lowerRight.x_ > XSIZE_PHYS)
    {
    	circleValues->velocity.x_ *= -1;
    }

    if(circleValues->upperLeft.y_ < 0 || circleValues->lowerRight.y_ > YSIZE_PHYS)
    {
    	circleValues->velocity.y_ *= -1;
    }

    circleValues->circleCenter.x_ += circleValues->velocity.x_;
    circleValues->circleCenter.y_ += circleValues->velocity.y_;
}

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/

