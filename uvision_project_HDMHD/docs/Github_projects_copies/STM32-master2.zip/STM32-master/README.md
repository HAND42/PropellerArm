# STM32
## STM32 Projects based on HAL functions

Here I will only add those files which require frequent updation

The full projects can be downloaded from the website www.controllerstech.com

