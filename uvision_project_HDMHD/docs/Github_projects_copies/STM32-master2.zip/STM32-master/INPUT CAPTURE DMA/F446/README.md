# Input Capture using the DMA 

It's useful for measuring the WIDTH and Frequency of the signal upto Few MHz Range ( 18 MHz in my Case)

Width was measurable as low as 30 nanosec

Follow the Configuration in the .IOC file

Copy the code from the Main.c file


## Watch the Video https://youtu.be/qqzZ9C0umQ4
