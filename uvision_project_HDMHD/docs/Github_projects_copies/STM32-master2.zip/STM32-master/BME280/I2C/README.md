# Interface BME280 with STM32 using I2C

1. Define the I2C instance in ```BME280_STM32.c``` File
2. Define the ```64 Bit / 32 Bit Support ```

To watch the implementation, or How I manage to write the library using the datasheet, check out the video https://youtu.be/jDhkfe2YG_o

To download the full project for Bluepill, goto https://controllerstech.com/bme280-with-stm32/
