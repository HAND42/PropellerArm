# LCD1602 using I2C and REGISTERS only



## USE THIS ONLY IF YOU KNOW HOW TO WORK WITH REGISTERS.


The code here works with F446RE, But you can change the configuration according to your MCU

All the files need to be modified except the ``` i2c-lcd.c ``` and ``` i2c-lcd.h ```




## Check out the Register Based Programming Series for STM32 

https://www.youtube.com/playlist?list=PLfIJKC1ud8ghc4eFhI84z_3p3Ap2MCMV-
