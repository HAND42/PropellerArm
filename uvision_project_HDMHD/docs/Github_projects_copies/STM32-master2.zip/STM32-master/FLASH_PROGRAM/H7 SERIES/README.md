# How to write data in the FLASH memory of ```H7 Series``` MCU


1. Choose the MCU in ```FLASH_SECTOR_H7.c``` file
2. Rewrite the Sectors according to your reference manual
3. If VOLTAGE RANGE throws error, just comment it out

## Always Refer to the manual, as some sectors are write protected.
