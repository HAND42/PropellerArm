# LVGL and STM32

### Along with the project, you also need to download the LVGL libray, which can be downladed from https://github.com/lvgl/lvgl.git


To watch the steps of implementation, check out https://youtu.be/X8aEXnSmPUI


This version uses the simple FLushing technique by flushing one row at a time.
