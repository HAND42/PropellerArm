# STM32 TIMER in ENCODER Mode

Watch the VIDEO for the Setup Process https://youtu.be/xqzWQgpqHmI

## Speed is Expreimental and need some testing

Some code is written in the Interrupt.c File also. Basically we need the SysTick Handler to calculate the Speed
