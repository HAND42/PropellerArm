# EEPROM Library for STM32 using HAL

This EEPROM Library uses HAL I2C Functions to communnicate with the EEPROM

Typically Written for AT24XXX Series, but others are free to try

To read about the functions, go to https://controllerstech.com/eeprom-and-stm32/

To check out the video go to https://youtu.be/-tV2pPXZ4VM
