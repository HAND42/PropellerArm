# How to write and Read data to N25Qxxx using the QSPI

The steps are commented out in the main file itself

## Check out the Video of implementation 
https://youtu.be/xIfh_uYy-OU

__________________________________________________________________________________________________________________

# How to configure N25Q in the mmeory mapped mode 

The steps are commented out in the main file itself

You have to also use the Folder `EXT_MEM_BOOT` to boot from the External flash.
Read the README File inside that folder for more details

## Check out the Video of implementation 
https://youtu.be/gAyuF20ok8c
