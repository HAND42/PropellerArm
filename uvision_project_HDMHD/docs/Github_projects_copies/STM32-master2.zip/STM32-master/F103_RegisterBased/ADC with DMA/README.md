# How to program F103 ADC with DMA using REGISTERS

It also covers the internal Temperature Sensor

3 channels of the ADC1, channel 1, 4 and the Internal Temp Sensor, are selected.


To watch it in action, goto https://youtu.be/Ysp8hpp8bxI

To Read the content, goto https://controllerstech.com/dma-with-adc-using-registers-in-stm32/
